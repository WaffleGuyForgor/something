			



# 🎖️ Custom Rank Prefix Pack

A high-quality pack of custom **rank prefixes** using symbols designed specifically for Minecraft servers.  
Each rank is linked to a special character that can be used as a prefix for your users.

## 🔧 How to use

To set a rank prefix, simply use the **symbol that corresponds to the rank** in your plugin (like LuckPerms).

> ✅ Example:
> ```
> /lp user Elizz meta setprefix " "
> ```
> This will display the **Owner** prefix before the name.

## 🧩 Rank Symbol Reference

| Rank     | Symbol |
|----------|--------|
| Manager  |       |
| Sr Admin |       |
| Builder  |       |
| Staff    |       |
| MVP      |       |
| VIP      |       |
| Member   |       |
| Dev      |       |
| Helper   |       |
| Mod      |       |
| Admin    |       |
| Owner    |       |

Make sure you copy and paste the correct symbol when setting up prefixes.

---

## 📦 What's Included

- Full character set for 12 server ranks  
- Clean pixel-art style, perfect for modern Minecraft UI  
- Easy-to-integrate with permission plugins

## ⚠️ Legal & Usage Notes

- You are free to use this resource for **personal and commercial servers**.
- Redistribution or resale of the pack is **not allowed**.
- No external dependencies are required.

---

**Created by Elizz**  
For help or custom requests, feel free to contact me!
Rank:	            Character:

manager						
sradmin						
builder						
staff						
mvp						
vip						
member						
dev						
helper						
mod						
admin						
owner						


